exports.owners =["حط أيدي أونر البوت"];
